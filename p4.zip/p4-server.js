/*
    CIT 281 Project 4
    Name: Emily Deng
*/
const p4 = require("./p4-module");
const fastify = require("fastify")();

// Route: /cit/question
fastify.get("/cit/question", (request, reply) => {
    reply
      .code(200)
      .header("Content-Type", "application/json; charset=utf-8")
      .send(p4.getQuestions());
  });

// Route: /cit/answer
fastify.get("/cit/answer", (request, reply) => {
    reply
      .code(200)
      .header("Content-Type", "application/json; charset=utf-8")
      .send(p4.getAnswers());
  });

// Route: /cit/questionanswer
fastify.get("/cit/questionanswer", (request, reply) => {
    reply
      .code(200)
      .header("Content-Type", "application/json; charset=utf-8")
      .send(p4.getQuestionsAnswers());
  });

// Route: /cit/question/:number
fastify.get("/cit/question/:number", (request, reply) => {
    reply
      .code(200)
      .header("Content-Type", "application/json; charset=utf-8")
      .send(p4.getQuestion(request.params.number));
  });

// Route: /cit/answer/:number
fastify.get("/cit/answer/:number", (request, reply) => {
    reply
      .code(200)
      .header("Content-Type", "application/json; charset=utf-8")
      .send(p4.getAnswer(request.params.number));
  });

// Route: /cit/questionanswer/:number
fastify.get("/cit/questionanswer/:number", (request, reply) => {
    reply
      .code(200)
      .header("Content-Type", "application/json; charset=utf-8")
      .send(p4.getQuestionAnswer(request.params.number));
  });

// Route: *
fastify.get("*", (request, reply) => {
    reply
      .code(404)
      .header("Content-Type", "text/html; charset=utf-8")
      .send("<h1>Route not found</h1>");
  });

// Extra Credit: Add support for POST
fastify.post("/cit/students/add", (request, reply) => {
    let userData = JSON.parse(request.body)
    console.log(userData);
});

const listenIP = "localhost";
const listenPort = 8080;
fastify.listen(listenPort, listenIP, (err, address) => {
  if (err) {
    console.log(err);
    process.exit(1);
  }
  console.log(`Server listening on ${address}`);
});