const data = require('./p4-data');

function addQuestionAnswer(info = {}) {

}

function getQuestions() {
    return data.data.map(x => x.question);
}

function getAnswers() {
    return data.data.map(x => x.answer);
}

function getQuestionsAnswers() {
    return data.data.slice(0);
}

function getQuestion(number = "") {
    if (isNaN(parseInt(number))) {
        return {
            error: 'Question number must be an integer',
            question: '',
            number: ''
        };
    }
    if (parseInt(number) > data.data.length) {
        return {
            error: 'Question number must be less than the number of questions (3)',
            question: '',
            number: ''
        };
    };
    if (parseInt(number) < 1) {
        return { 
            error: 'Question number must be >= 1', 
            question: '', 
            number: '' 
        };
    }
    const q = data.data.filter(x => x.question === 'Q' + number);
    if (q.length === 1) {
        return {
            error: '',
            question: q[0].question,
            number: q[0].question.substring(1)
        };
    }
}

function getAnswer(number = "") {
    if (isNaN(parseInt(number))) {
        return {
            error: 'Answer number must be an integer',
            answer: '',
            number: ''
        };
    }
    if (parseInt(number) > data.data.length) {
        return {
            error: 'Answer number must be less than the number of questions (3)',
            answer: '',
            number: ''
        };
    };
    if (parseInt(number) < 1) {
        return { 
            error: 'Answer number must be >= 1', 
            answer: '', 
            number: '' 
        };
    }
    const a = data.data.filter(x => x.answer === 'A' + number);
    if (a.length === 1) {
        return {
            error: '',
            answer: a[0].answer,
            number: a[0].answer.substring(1)
        };
    }
} 

function getQuestionAnswer(number = "") {
    if (isNaN(parseInt(number))) {
        return {
            error: 'Question number must be an integer',
            question: '',
            number: ''
        };
    }
    if (parseInt(number) > data.data.length) {
        return {
            error: 'Question number must be less than the number of questions (3)',
            question: '',
            number: ''
        };
    };
    if (parseInt(number) < 1) {
        return { 
            error: 'Question number must be >= 1', 
            question: '', 
            number: '' 
        };
    }
    const q = data.data.filter(x => x.question === 'Q' + number);
    if (q.length === 1) {
        return {
            error: '',
            question: q[0].question,
            answer: q[0].answer,
            number: q[0].question.substring(1)
        };
    }
}

module.exports = {
    getQuestions,
    getAnswers,
    getQuestionsAnswers,
    getQuestion,
    getAnswer,
    getQuestionAnswer
};