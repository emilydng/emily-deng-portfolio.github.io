// Required code modules

function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

module.exports = class Monster {
    constructor({
      monsterName = 'Unknown',
      minimumLife = 0,
      currentLife = 100,
    }) {
        this.minimumLife = minimumLife;
        this.currentLife = currentLife;
        this.monsterName = monsterName;
        this.isAlive = currentLife >= minimumLife
    };
    updateLife = (lifeChangeAmount) => {
        this.currentLife = Math.max(this.currentLife
             + lifeChangeAmount, 0);
        this.isAlive = this.currentLife >= this.minimumLife;
    };
    randomLifeDrain = (minimumLifeDrain, maximumLifeDrain) => {
        if (minimumLifeDrain < maximumLifeDrain) {
            this.updateLife(getRandomInteger(minimumLifeDrain, maximumLifeDrain + 1)*-1);
        }
    }
};
