/*
    CIT 281 Project 1
    Name: Emily Deng
*/
var weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
var d = new Date();
var num = d.getDay();
var name = weekDays[num];
console.log(name);