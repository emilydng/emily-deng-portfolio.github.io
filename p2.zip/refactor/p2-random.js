/*
    CIT 281 Project 2
    Name: Emily Deng
*/

// will return a single, random, lowercase letter
function getRandomLetter() {

    const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");

    return alphabet[Math.floor(Math.random() * alphabet.length)];
}

// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

// will return a random length string between 10 and 20 characters
function getRandomString(minLength, maxLength) {
    let length = Math.floor(Math.random() * (maxLength - minLength) + minLength);
    let string = "";
    for (let i = 0; i < length; i++) {
        string += getRandomLetter();
    }
    return string;
}

// return a string in ascending order
function getSortedString(string) {
    return string.split("").sort().join("");
}

console.log(getSortedString(getRandomString(10, 20)));
