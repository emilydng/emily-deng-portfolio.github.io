const fs = require('fs');
const fastify = require('fastify')();
const p3 = require('./p3-module');

fastify.get('/', (request, reply) => {
    fs.readFile(__dirname + '/index.html', (err, data) => {
        if (err) {
            reply
                .code(500);
        }
        else {
            reply
                .code(200)
                .header('Content-Type', 'text/html; charset=utf-8')
                .send(data);
        }
    });
});

fastify.get('/coin', (request, reply) => {

    const coins = {denom: parseInt(request.query.denom), count: parseInt(request.query.count)};
    const coinValue = p3.coinCount(coins);
    reply
      .code(200)
      .header("Content-Type", "text/html; charset=utf-8")
      .send(`<h2>Value of ${coins.count} of ${coins.denom} is ${coinValue}</h2><br /><a href="/">Home</a>`);
})

fastify.get('/coins', (request, reply) => {
    const coins = [{denom: 25, count: 2},{denom: 1, count: 7}];
    switch (request.query.option) {
        case '1':
            coinValue = p3.coinCount({ denom: 5, count: 3 }, { denom: 10, count: 2 });
            break;
        case '2':
            coinValue = p3.coinCount(...coins);
            break;
        case '3':
            coinValue = p3.coinCount(coins);
            break;
        default:
            coinValue = 0;
            break;
    }
    reply
      .code(200)
      .header("Content-Type", "text/html; charset=utf-8")
      .send(`<h2>Option ${request.query.option} value is ${coinValue}</h2><br /><a href="/">Home</a>`);

})

const listenIP = 'localhost';
const listenPort = 8080;

fastify.listen(listenPort, listenIP, (err, address) => {
    if (err) {
       console.log(err);
       process.exit(1); 
    }
    console.log(`Server listening on ${address}`);
});

