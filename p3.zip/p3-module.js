/*
    CIT 281 Project 3
    Name: Emily Deng
*/

function validDenomination(coin) {
    const validCoins = [1, 5, 10, 25, 50, 100];
    return (validCoins.indexOf(coin) !== -1);
}

function valueFromCoinObject(obj) {
    //denom: Coin denomination, must be either 1, 5, 10, 25, 50, or 100
    //count: The number of the specified coin

    const denom = obj.denom;
    const count = obj.count;
    return denom*count;

}

function valueFromArray(arr) {
    const reducer = (total, current) => {
        if (Array.isArray(current)) {
            return total + current.reduce(reducer, total);
        }
        return total + valueFromCoinObject(current);
    };
    return arr.reduce(reducer, 0);
}

exports.coinCount = (...coinage) => {
    return valueFromArray(coinage);
}

/*
console.log("{}", coinCount({denom: 5, count: 3}));
console.log("{}s", coinCount({denom: 5, count: 3},{denom: 10, count: 2}));
const coins = [{denom: 25, count: 2},{denom: 1, count: 7}];
console.log("...[{}]", coinCount(...coins));
console.log("[{}]", coinCount(coins));  // Extra credit
*/

